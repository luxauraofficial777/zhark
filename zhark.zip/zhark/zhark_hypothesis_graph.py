"""ZHARK — Hypothesis Graph.

A directed acyclic graph (DAG) of hypotheses with weighted evidence,
contradiction tracking, and confidence scoring. Each hypothesis can spawn
sub-hypotheses, forming a tree of investigation that ZHARK explores
autonomously over multi-hour cycles.

Key concepts:
  - Hypothesis: A testable claim about the research domain
  - Evidence: A piece of data supporting or refuting a hypothesis
  - Confidence: Weighted score [-1.0, 1.0] from accumulated evidence
  - Contradiction: When evidence for one hypothesis conflicts with another
  - Branching: Sub-hypotheses spawned to investigate specific aspects
"""

from __future__ import annotations

import json
import threading
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from pathlib import Path
from typing import Any, Dict, List, Optional, Set, Tuple


class HypothesisStatus(str, Enum):
    PENDING = "pending"
    INVESTIGATING = "investigating"
    SUPPORTED = "supported"
    REFUTED = "refuted"
    INCONCLUSIVE = "inconclusive"
    SUPERSEDED = "superseded"


@dataclass
class Evidence:
    """A single piece of evidence for or against a hypothesis."""
    evidence_id: str = field(default_factory=lambda: uuid.uuid4().hex[:12])
    source: str = ""  # URL, document name, or data source identifier
    content: str = ""  # The actual evidence text or summary
    supports: bool = True  # True = supports hypothesis, False = refutes
    weight: float = 1.0  # Confidence weight [0.1, 1.0]
    timestamp: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
    metadata: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "evidence_id": self.evidence_id,
            "source": self.source,
            "content": self.content[:500],
            "supports": self.supports,
            "weight": self.weight,
            "timestamp": self.timestamp,
            "metadata": self.metadata,
        }


@dataclass
class Hypothesis:
    """A testable claim in the research graph."""
    hypothesis_id: str = field(default_factory=lambda: uuid.uuid4().hex[:12])
    statement: str = ""  # The claim being investigated
    parent_id: Optional[str] = None  # Parent hypothesis (None = root)
    status: str = HypothesisStatus.PENDING.value
    confidence: float = 0.0  # [-1.0, 1.0], negative = refuted
    evidence: List[Evidence] = field(default_factory=list)
    sub_hypotheses: List[str] = field(default_factory=list)  # IDs of children
    depth: int = 0  # 0 = root, 1 = first branch, etc.
    created: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
    last_updated: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
    investigation_cycles: int = 0  # How many gather-analyze rounds
    contradictions: List[str] = field(default_factory=list)  # IDs of conflicting hypotheses
    metadata: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "hypothesis_id": self.hypothesis_id,
            "statement": self.statement,
            "parent_id": self.parent_id,
            "status": self.status,
            "confidence": round(self.confidence, 3),
            "evidence_count": len(self.evidence),
            "evidence": [e.to_dict() for e in self.evidence[-10:]],  # Last 10 for brevity
            "sub_hypotheses": self.sub_hypotheses,
            "depth": self.depth,
            "created": self.created,
            "last_updated": self.last_updated,
            "investigation_cycles": self.investigation_cycles,
            "contradictions": self.contradictions,
            "metadata": self.metadata,
        }


class HypothesisGraph:
    """Thread-safe DAG of hypotheses with evidence tracking.

    Supports:
      - Adding root and sub-hypotheses
      - Attaching evidence with weighted confidence scoring
      - Detecting contradictions between hypotheses
      - Querying by status, confidence threshold, or depth
      - Serialization for checkpoint/resume
    """

    def __init__(self):
        self._hypotheses: Dict[str, Hypothesis] = {}
        self._lock = threading.RLock()
        self._root_ids: List[str] = []

    def add_hypothesis(
        self,
        statement: str,
        parent_id: Optional[str] = None,
        metadata: Optional[Dict] = None,
    ) -> Hypothesis:
        """Add a new hypothesis to the graph."""
        with self._lock:
            depth = 0
            if parent_id and parent_id in self._hypotheses:
                parent = self._hypotheses[parent_id]
                depth = parent.depth + 1
                parent.sub_hypotheses.append("")  # Placeholder, updated below

            hyp = Hypothesis(
                statement=statement,
                parent_id=parent_id,
                depth=depth,
                metadata=metadata or {},
            )

            if parent_id and parent_id in self._hypotheses:
                parent = self._hypotheses[parent_id]
                parent.sub_hypotheses[-1] = hyp.hypothesis_id
                parent.last_updated = hyp.created

            self._hypotheses[hyp.hypothesis_id] = hyp
            if parent_id is None:
                self._root_ids.append(hyp.hypothesis_id)
            return hyp

    def add_evidence(
        self,
        hypothesis_id: str,
        evidence: Evidence,
    ) -> Optional[Hypothesis]:
        """Attach evidence to a hypothesis and update confidence."""
        with self._lock:
            hyp = self._hypotheses.get(hypothesis_id)
            if not hyp:
                return None

            hyp.evidence.append(evidence)
            hyp.investigation_cycles += 1
            hyp.last_updated = datetime.now(timezone.utc).isoformat()

            # Recalculate confidence as weighted sum
            total_support = sum(e.weight for e in hyp.evidence if e.supports)
            total_refute = sum(e.weight for e in hyp.evidence if not e.supports)
            net = total_support - total_refute
            total = total_support + total_refute
            hyp.confidence = net / total if total > 0 else 0.0

            # Update status based on confidence
            if hyp.confidence >= 0.7 and total >= 3:
                hyp.status = HypothesisStatus.SUPPORTED.value
            elif hyp.confidence <= -0.5 and total >= 3:
                hyp.status = HypothesisStatus.REFUTED.value
            elif total >= 5 and abs(hyp.confidence) < 0.3:
                hyp.status = HypothesisStatus.INCONCLUSIVE.value

            return hyp

    def detect_contradictions(self) -> List[Tuple[str, str, str]]:
        """Detect contradictions between hypotheses at the same depth.

        Returns list of (hyp_id_1, hyp_id_2, reason) tuples.
        """
        contradictions = []
        with self._lock:
            # Group by parent
            by_parent: Dict[Optional[str], List[Hypothesis]] = {}
            for hyp in self._hypotheses.values():
                by_parent.setdefault(hyp.parent_id, []).append(hyp)

            for parent_id, siblings in by_parent.items():
                for i, h1 in enumerate(siblings):
                    for h2 in siblings[i + 1:]:
                        # If one is strongly supported and the other is refuted
                        if (h1.confidence > 0.5 and h2.confidence < -0.3) or \
                           (h2.confidence > 0.5 and h1.confidence < -0.3):
                            contradictions.append((
                                h1.hypothesis_id,
                                h2.hypothesis_id,
                                f"Conflicting confidence: {h1.statement[:60]} vs {h2.statement[:60]}",
                            ))
                            h1.contradictions.append(h2.hypothesis_id)
                            h2.contradictions.append(h1.hypothesis_id)

        return contradictions

    def get(self, hypothesis_id: str) -> Optional[Hypothesis]:
        with self._lock:
            return self._hypotheses.get(hypothesis_id)

    def get_roots(self) -> List[Hypothesis]:
        with self._lock:
            return [self._hypotheses[hid] for hid in self._root_ids if hid in self._hypotheses]

    def get_by_status(self, status: str) -> List[Hypothesis]:
        with self._lock:
            return [h for h in self._hypotheses.values() if h.status == status]

    def get_pending(self, max_depth: int = 10) -> List[Hypothesis]:
        """Get hypotheses that still need investigation."""
        with self._lock:
            return [
                h for h in self._hypotheses.values()
                if h.status in (HypothesisStatus.PENDING.value, HypothesisStatus.INVESTIGATING.value)
                and h.depth < max_depth
            ]

    def get_supported(self, min_confidence: float = 0.5) -> List[Hypothesis]:
        with self._lock:
            return [
                h for h in self._hypotheses.values()
                if h.status == HypothesisStatus.SUPPORTED.value and h.confidence >= min_confidence
            ]

    def get_tree(self, root_id: Optional[str] = None) -> Dict[str, Any]:
        """Get a nested tree representation of the hypothesis graph."""
        with self._lock:
            def _build(hyp_id: str) -> Dict[str, Any]:
                hyp = self._hypotheses.get(hyp_id)
                if not hyp:
                    return {}
                return {
                    **hyp.to_dict(),
                    "children": [_build(cid) for cid in hyp.sub_hypotheses if cid in self._hypotheses],
                }

            if root_id:
                return _build(root_id)
            return {"roots": [_build(rid) for rid in self._root_ids if rid in self._hypotheses]}

    def summary(self) -> Dict[str, Any]:
        """Get summary statistics of the graph."""
        with self._lock:
            total = len(self._hypotheses)
            by_status: Dict[str, int] = {}
            total_evidence = 0
            for hyp in self._hypotheses.values():
                by_status[hyp.status] = by_status.get(hyp.status, 0) + 1
                total_evidence += len(hyp.evidence)

            return {
                "total_hypotheses": total,
                "by_status": by_status,
                "total_evidence": total_evidence,
                "root_count": len(self._root_ids),
                "max_depth": max((h.depth for h in self._hypotheses.values()), default=0),
            }

    def save(self, path: str | Path) -> str:
        """Save graph to JSON for checkpoint/resume."""
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        with self._lock:
            data = {
                "root_ids": self._root_ids,
                "hypotheses": {hid: h.to_dict() for hid, h in self._hypotheses.items()},
            }
        path.write_text(json.dumps(data, indent=2, default=str), encoding="utf-8")
        return str(path)

    def load(self, path: str | Path) -> bool:
        """Load graph from JSON checkpoint."""
        path = Path(path)
        if not path.exists():
            return False
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
            with self._lock:
                self._root_ids = data.get("root_ids", [])
                self._hypotheses = {}
                for hid, hdata in data.get("hypotheses", {}).items():
                    hyp = Hypothesis(
                        hypothesis_id=hdata["hypothesis_id"],
                        statement=hdata["statement"],
                        parent_id=hdata.get("parent_id"),
                        status=hdata.get("status", HypothesisStatus.PENDING.value),
                        confidence=hdata.get("confidence", 0.0),
                        sub_hypotheses=hdata.get("sub_hypotheses", []),
                        depth=hdata.get("depth", 0),
                        created=hdata.get("created", ""),
                        last_updated=hdata.get("last_updated", ""),
                        investigation_cycles=hdata.get("investigation_cycles", 0),
                        contradictions=hdata.get("contradictions", []),
                        metadata=hdata.get("metadata", {}),
                    )
                    hyp.evidence = [Evidence(**e) for e in hdata.get("evidence", [])]
                    self._hypotheses[hid] = hyp
            return True
        except Exception:
            return False
