"""ZHARK — Autonomous Long-Horizon Research & Strategy Engine.

Virtual CSO for ultra-deep research. Domestic equivalent to Sakana Marlin.
Runs multi-hour autonomous investigation cycles with hypothesis formation,
web data gathering, contradiction resolution, causal mapping, and
executive-ready strategy synthesis.

Modules:
  ZharkOrchestrator   — Main async loop controller
  HypothesisGraph     — DAG of hypotheses with evidence weights
  CausalMapper        — Causal relationship extraction and DAG construction
  StrategySynthesizer — Converts findings to executive-ready strategic options
  ZharkState          — Persistent state: checkpoint, resume, verification buffer
  WebGatherer         — Web search and content extraction
  VerifyBuffer        — Inference-time compute scaling, self-correction
"""

from .zhark_orchestrator import ZharkOrchestrator
from .zhark_hypothesis_graph import HypothesisGraph, Hypothesis, Evidence
from .zhark_causal_mapper import CausalMapper, CausalNode, CausalEdge
from .zhark_strategy_synthesizer import StrategySynthesizer, StrategyOption
from .zhark_state import ZharkState
from .zhark_web_gatherer import WebGatherer
from .zhark_verify import VerifyBuffer

__all__ = [
    "ZharkOrchestrator",
    "HypothesisGraph",
    "Hypothesis",
    "Evidence",
    "CausalMapper",
    "CausalNode",
    "CausalEdge",
    "StrategySynthesizer",
    "StrategyOption",
    "ZharkState",
    "WebGatherer",
    "VerifyBuffer",
]

__version__ = "1.0.0"
