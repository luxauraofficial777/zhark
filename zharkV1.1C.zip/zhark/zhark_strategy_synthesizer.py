"""ZHARK — Strategy Synthesizer.

Converts the hypothesis graph and causal map into executive-ready strategic
options. Each option includes:
  - Recommended action
  - Rationale (linked to evidence and causal paths)
  - Risk assessment
  - Resource requirements
  - Timeline estimate
  - Confidence score
  - Key assumptions
  - Leading indicators to monitor

The synthesizer uses the causal map's leverage points to identify high-impact
interventions and the hypothesis graph's confidence scores to assess certainty.
"""

from __future__ import annotations

import json
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from .zhark_hypothesis_graph import HypothesisGraph, Hypothesis
from .zhark_causal_mapper import CausalMapper, CausalNode


class StrategyRisk(str, Enum):
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"


class StrategyTimeframe(str, Enum):
    IMMEDIATE = "immediate"    # 0-30 days
    SHORT = "short_term"       # 1-3 months
    MEDIUM = "medium_term"     # 3-12 months
    LONG = "long_term"         # 1+ years


@dataclass
class StrategyOption:
    """An executive-ready strategic recommendation."""
    option_id: str = field(default_factory=lambda: uuid.uuid4().hex[:12])
    title: str = ""
    description: str = ""
    rationale: str = ""
    recommended_action: str = ""
    risk_level: str = StrategyRisk.MEDIUM.value
    timeframe: str = StrategyTimeframe.MEDIUM.value
    confidence: float = 0.5  # [0, 1]
    resource_requirements: str = ""
    key_assumptions: List[str] = field(default_factory=list)
    leading_indicators: List[str] = field(default_factory=list)
    evidence_refs: List[str] = field(default_factory=list)  # Hypothesis IDs
    causal_leverage_points: List[str] = field(default_factory=list)  # Node names
    alternatives: List[str] = field(default_factory=list)  # Alternative option IDs
    metadata: Dict[str, Any] = field(default_factory=dict)
    created: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())

    def to_dict(self) -> Dict[str, Any]:
        return {
            "option_id": self.option_id,
            "title": self.title,
            "description": self.description,
            "rationale": self.rationale,
            "recommended_action": self.recommended_action,
            "risk_level": self.risk_level,
            "timeframe": self.timeframe,
            "confidence": round(self.confidence, 3),
            "resource_requirements": self.resource_requirements,
            "key_assumptions": self.key_assumptions,
            "leading_indicators": self.leading_indicators,
            "evidence_refs": self.evidence_refs,
            "causal_leverage_points": self.causal_leverage_points,
            "alternatives": self.alternatives,
            "metadata": self.metadata,
            "created": self.created,
        }


class StrategySynthesizer:
    """Synthesizes executive-ready strategy from research findings.

    Inputs:
      - HypothesisGraph with supported/refuted hypotheses
      - CausalMapper with leverage points and causal paths
      - LLM provider for natural language synthesis

    Output:
      - List of StrategyOption with full rationale and risk assessment
    """

    def __init__(self, llm_provider=None):
        self._llm = llm_provider
        self._options: List[StrategyOption] = []

    def synthesize(
        self,
        hypothesis_graph: HypothesisGraph,
        causal_mapper: CausalMapper,
        research_question: str = "",
        max_options: int = 5,
    ) -> List[StrategyOption]:
        """Generate strategic options from research findings."""
        self._options = []

        # Gather inputs
        supported = hypothesis_graph.get_supported(min_confidence=0.3)
        leverage_points = causal_mapper.get_leverage_points(top_n=10)
        causal_summary = causal_mapper.summary()
        graph_summary = hypothesis_graph.summary()

        if not supported and not leverage_points:
            # Insufficient evidence — generate a "further research needed" option
            opt = StrategyOption(
                title="Further Research Required",
                description=f"Insufficient evidence to synthesize strategy for: {research_question}",
                rationale="The current hypothesis graph does not have enough supported hypotheses "
                          "to generate confident strategic recommendations.",
                recommended_action="Continue investigation with additional data sources and deeper analysis.",
                risk_level=StrategyRisk.LOW.value,
                timeframe=StrategyTimeframe.IMMEDIATE.value,
                confidence=0.2,
                key_assumptions=["Current evidence base is incomplete"],
                leading_indicators=["Hypothesis confidence scores", "Evidence count growth"],
            )
            self._options.append(opt)
            return self._options

        # Build LLM prompt for synthesis
        if self._llm:
            options = self._llm_synthesize(
                research_question, supported, leverage_points,
                causal_summary, graph_summary, max_options,
            )
            self._options = options
        else:
            # Fallback: generate options from leverage points without LLM
            self._options = self._heuristic_synthesize(
                research_question, supported, leverage_points, max_options,
            )

        return self._options

    def _llm_synthesize(
        self,
        question: str,
        supported: List[Hypothesis],
        leverage_points: List[CausalNode],
        causal_summary: Dict,
        graph_summary: Dict,
        max_options: int,
    ) -> List[StrategyOption]:
        """Use LLM to synthesize strategic options."""
        # Build context
        hyp_text = "\n".join([
            f"- [{h.confidence:.2f}] {h.statement}"
            for h in supported[:15]
        ])
        leverage_text = "\n".join([
            f"- {n.name} (centrality: {n.centrality:.2f}, leverage: {n.leverage_score:.2f})"
            for n in leverage_points
        ])

        system = (
            "You are ZHARK, an autonomous Virtual CSO research engine. "
            "Your task is to synthesize executive-ready strategic options from "
            "research findings. Each option must include: title, description, "
            "rationale, recommended action, risk level, timeframe, confidence, "
            "key assumptions, and leading indicators. Output as JSON array."
        )

        prompt = f"""Research Question: {question}

## Supported Hypotheses (confidence scores):
{hyp_text}

## Causal Leverage Points:
{leverage_text}

## Causal Map Summary:
{json.dumps(causal_summary, indent=2)}

## Hypothesis Graph Summary:
{json.dumps(graph_summary, indent=2)}

## Task:
Synthesize {max_options} strategic options. For each option, provide:
1. title: Short executive title
2. description: 2-3 sentence summary
3. rationale: Why this option, linked to evidence
4. recommended_action: Specific actionable steps
5. risk_level: low/medium/high/critical
6. timeframe: immediate/short_term/medium_term/long_term
7. confidence: 0.0-1.0 based on evidence strength
8. key_assumptions: List of assumptions made
9. leading_indicators: Metrics to monitor
10. resource_requirements: What's needed to execute

Output as a JSON array of objects. Be specific and actionable."""

        result = self._llm.generate(prompt, system=system, temperature=0.4, max_tokens=4096)

        if not result.get("ok"):
            return self._heuristic_synthesize(question, supported, leverage_points, max_options)

        # Parse LLM output
        try:
            output_text = result.get("output", "")
            # Find JSON array in output
            start = output_text.find("[")
            end = output_text.rfind("]") + 1
            if start >= 0 and end > start:
                options_data = json.loads(output_text[start:end])
                options = []
                for odata in options_data[:max_options]:
                    opt = StrategyOption(
                        title=odata.get("title", "Untitled"),
                        description=odata.get("description", ""),
                        rationale=odata.get("rationale", ""),
                        recommended_action=odata.get("recommended_action", ""),
                        risk_level=odata.get("risk_level", StrategyRisk.MEDIUM.value),
                        timeframe=odata.get("timeframe", StrategyTimeframe.MEDIUM.value),
                        confidence=min(1.0, max(0.0, float(odata.get("confidence", 0.5)))),
                        resource_requirements=odata.get("resource_requirements", ""),
                        key_assumptions=odata.get("key_assumptions", []),
                        leading_indicators=odata.get("leading_indicators", []),
                        evidence_refs=[h.hypothesis_id for h in supported[:5]],
                        causal_leverage_points=[n.name for n in leverage_points[:5]],
                    )
                    options.append(opt)
                return options
        except (json.JSONDecodeError, ValueError, KeyError):
            pass

        return self._heuristic_synthesize(question, supported, leverage_points, max_options)

    def _heuristic_synthesize(
        self,
        question: str,
        supported: List[Hypothesis],
        leverage_points: List[CausalNode],
        max_options: int,
    ) -> List[StrategyOption]:
        """Generate options without LLM using heuristic rules."""
        options: List[StrategyOption] = []

        # Option 1: Act on highest-confidence hypothesis
        if supported:
            best = max(supported, key=lambda h: h.confidence)
            opt = StrategyOption(
                title=f"Act on: {best.statement[:60]}",
                description=f"Based on strong evidence (confidence: {best.confidence:.2f}), "
                           f"execute strategy aligned with: {best.statement}",
                rationale=f"Supported by {len(best.evidence)} pieces of evidence "
                         f"with net confidence {best.confidence:.2f}.",
                recommended_action=f"Implement changes targeting: {best.statement}",
                risk_level=StrategyRisk.LOW if best.confidence > 0.7 else StrategyRisk.MEDIUM.value,
                timeframe=StrategyTimeframe.SHORT.value,
                confidence=best.confidence,
                key_assumptions=["Evidence base is representative", "No major confounders missed"],
                leading_indicators=["KPIs related to hypothesis", "Evidence stability over time"],
                evidence_refs=[best.hypothesis_id],
            )
            options.append(opt)

        # Option 2: Target top leverage point
        if leverage_points:
            top = leverage_points[0]
            opt = StrategyOption(
                title=f"Leverage: {top.name}",
                description=f"Focus on {top.name} — highest leverage point "
                           f"(centrality: {top.centrality:.2f}) in the causal map.",
                rationale=f"{top.name} has the highest centrality×leverage score, "
                         f"meaning changes here cascade to many downstream effects.",
                recommended_action=f"Develop intervention targeting {top.name}",
                risk_level=StrategyRisk.MEDIUM.value,
                timeframe=StrategyTimeframe.MEDIUM.value,
                confidence=0.5,
                key_assumptions=[f"{top.name} is controllable", "Causal map is accurate"],
                leading_indicators=[f"{top.name} metrics", "Downstream effect metrics"],
                causal_leverage_points=[top.name],
            )
            options.append(opt)

        # Option 3: Hedge — combine multiple moderate hypotheses
        moderate = [h for h in supported if 0.3 < h.confidence < 0.6]
        if moderate:
            opt = StrategyOption(
                title="Diversified Approach",
                description=f"Pursue {len(moderate)} parallel initiatives based on "
                           f"moderately-supported hypotheses.",
                rationale="Spreading risk across multiple hypotheses with moderate confidence "
                         "reduces single-point-of-failure risk.",
                recommended_action="Launch parallel pilot programs for each hypothesis",
                risk_level=StrategyRisk.LOW.value,
                timeframe=StrategyTimeframe.MEDIUM.value,
                confidence=0.4,
                key_assumptions=["Hypotheses are independent", "Resources allow parallel execution"],
                leading_indicators=["Pilot program KPIs", "Confidence score evolution"],
                evidence_refs=[h.hypothesis_id for h in moderate[:3]],
            )
            options.append(opt)

        return options[:max_options]

    def get_options(self) -> List[StrategyOption]:
        return self._options

    def to_report(self, format: str = "markdown") -> str:
        """Generate a formatted strategy report."""
        if format == "markdown":
            return self._to_markdown()
        elif format == "json":
            return json.dumps(
                [o.to_dict() for o in self._options], indent=2, default=str
            )
        return ""

    def _to_markdown(self) -> str:
        """Generate executive-ready markdown report."""
        lines = [
            "# ZHARK Strategic Analysis Report",
            f"Generated: {datetime.now(timezone.utc).isoformat()}",
            "",
        ]

        for i, opt in enumerate(self._options, 1):
            lines.extend([
                f"## Option {i}: {opt.title}",
                "",
                f"**Confidence:** {opt.confidence:.0%}  ",
                f"**Risk:** {opt.risk_level}  ",
                f"**Timeframe:** {opt.timeframe}",
                "",
                f"### Description",
                opt.description,
                "",
                f"### Rationale",
                opt.rationale,
                "",
                f"### Recommended Action",
                opt.recommended_action,
                "",
                f"### Resource Requirements",
                opt.resource_requirements or "To be determined.",
                "",
                f"### Key Assumptions",
            ])
            for a in opt.key_assumptions:
                lines.append(f"- {a}")
            lines.extend(["", f"### Leading Indicators"])
            for ind in opt.leading_indicators:
                lines.append(f"- {ind}")
            lines.append("")

        return "\n".join(lines)

    def save(self, path: str | Path, format: str = "json") -> str:
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        if format == "markdown":
            path.write_text(self._to_markdown(), encoding="utf-8")
        else:
            path.write_text(
                json.dumps([o.to_dict() for o in self._options], indent=2, default=str),
                encoding="utf-8",
            )
        return str(path)
