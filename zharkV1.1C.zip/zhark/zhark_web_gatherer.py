"""ZHARK — Web Gatherer.

Autonomous web data collection for the research loop. Uses search + content
extraction to gather evidence for hypotheses. Designed to work with:
  - DuckDuckGo (no API key required, rate-limited)
  - Custom search APIs (via environment variables)
  - Direct URL content extraction

All gathered data is tagged with source, timestamp, and relevance score
before being attached as evidence to the hypothesis graph.
"""

from __future__ import annotations

import json
import re
import time
import urllib.parse
import urllib.request
import urllib.error
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional


@dataclass
class SearchResult:
    """A single search result with extracted content."""
    url: str = ""
    title: str = ""
    snippet: str = ""
    content: str = ""  # Extracted page content (truncated)
    relevance: float = 0.0  # [0, 1] — relevance to query
    source: str = "duckduckgo"
    timestamp: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
    error: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        return {
            "url": self.url,
            "title": self.title,
            "snippet": self.snippet,
            "content": self.content[:1000],
            "relevance": round(self.relevance, 3),
            "source": self.source,
            "timestamp": self.timestamp,
            "error": self.error,
        }


class WebGatherer:
    """Autonomous web search and content extraction.

    Uses DuckDuckGo HTML scraping (no API key needed) as primary source.
    Falls back to direct URL fetching for known sources.
    Rate-limited to be respectful to search engines.

    For production use, configure a search API via environment variables:
      ZHARK_SEARCH_API_URL — Custom search endpoint
      ZHARK_SEARCH_API_KEY — API key for custom search
    """

    def __init__(
        self,
        max_results: int = 10,
        rate_limit_seconds: float = 2.0,
        max_content_length: int = 50000,
        timeout: int = 15,
    ):
        self.max_results = max_results
        self.rate_limit = rate_limit_seconds
        self.max_content_length = max_content_length
        self.timeout = timeout
        self._last_request_time = 0.0

    def search(self, query: str, max_results: Optional[int] = None) -> List[SearchResult]:
        """Search the web for a query and return results with content."""
        max_results = max_results or self.max_results
        self._rate_limit_wait()

        results = self._ddg_search(query, max_results)

        # Extract content from top results
        for result in results[:5]:  # Only fetch content for top 5
            if not result.error:
                content = self._fetch_content(result.url)
                result.content = content[:self.max_content_length] if content else ""
            time.sleep(0.5)  # Be respectful

        return results

    def _ddg_search(self, query: str, max_results: int) -> List[SearchResult]:
        """Search using DuckDuckGo HTML endpoint (no API key needed)."""
        results: List[SearchResult] = []
        try:
            url = f"https://html.duckduckgo.com/html/?q={urllib.parse.quote(query)}"
            req = urllib.request.Request(url, headers={
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) ZHARK/1.0"
            })
            with urllib.request.urlopen(req, timeout=self.timeout) as resp:
                html = resp.read().decode("utf-8", errors="ignore")

            # Parse results from HTML (simplified regex parsing)
            # DuckDuckGo HTML results have class="result__a" links
            link_pattern = re.compile(
                r'<a[^>]+class="result__a"[^>]+href="([^"]+)"[^>]*>(.*?)</a>',
                re.DOTALL,
            )
            snippet_pattern = re.compile(
                r'<a[^>]+class="result__snippet"[^>]*>(.*?)</a>',
                re.DOTALL,
            )

            links = link_pattern.findall(html)
            snippets = snippet_pattern.findall(html)

            for i, (href, title) in enumerate(links[:max_results]):
                # Clean HTML from title
                clean_title = re.sub(r"<[^>]+>", "", title).strip()
                # Decode redirect URL
                if href.startswith("//duckduckgo.com/l/?uddg="):
                    href = urllib.parse.unquote(
                        href.split("uddg=")[1].split("&")[0]
                    )
                snippet = ""
                if i < len(snippets):
                    snippet = re.sub(r"<[^>]+>", "", snippets[i]).strip()

                results.append(SearchResult(
                    url=href,
                    title=clean_title,
                    snippet=snippet,
                    source="duckduckgo",
                    relevance=1.0 - (i * 0.1),  # Decreasing relevance
                ))

        except Exception as e:
            results.append(SearchResult(
                error=f"DuckDuckGo search failed: {e}",
                source="duckduckgo",
            ))

        return results

    def _fetch_content(self, url: str) -> str:
        """Fetch and extract text content from a URL."""
        try:
            req = urllib.request.Request(url, headers={
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) ZHARK/1.0"
            })
            with urllib.request.urlopen(req, timeout=self.timeout) as resp:
                html = resp.read().decode("utf-8", errors="ignore")

            # Strip HTML tags (simplified)
            # Remove script and style content
            html = re.sub(r"<script[^>]*>.*?</script>", "", html, flags=re.DOTALL | re.IGNORECASE)
            html = re.sub(r"<style[^>]*>.*?</style>", "", html, flags=re.DOTALL | re.IGNORECASE)
            # Remove all tags
            text = re.sub(r"<[^>]+>", " ", html)
            # Clean whitespace
            text = re.sub(r"\s+", " ", text).strip()
            return text

        except urllib.error.HTTPError as e:
            return f"[HTTP {e.code}] {e.reason}"
        except Exception as e:
            return f"[Error] {e}"

    def _rate_limit_wait(self) -> None:
        """Enforce rate limiting between requests."""
        elapsed = time.time() - self._last_request_time
        if elapsed < self.rate_limit:
            time.sleep(self.rate_limit - elapsed)
        self._last_request_time = time.time()

    def gather_evidence(
        self,
        hypothesis: str,
        search_queries: Optional[List[str]] = None,
    ) -> List[SearchResult]:
        """Gather web evidence for a hypothesis.

        Generates search queries from the hypothesis statement if not provided.
        """
        if not search_queries:
            search_queries = self._generate_queries(hypothesis)

        all_results: List[SearchResult] = []
        for query in search_queries:
            results = self.search(query, max_results=5)
            all_results.extend(results)

        # Deduplicate by URL
        seen_urls: set = set()
        unique: List[SearchResult] = []
        for r in all_results:
            if r.url and r.url not in seen_urls:
                seen_urls.add(r.url)
                unique.append(r)

        return unique[:20]  # Cap at 20 results

    @staticmethod
    def _generate_queries(hypothesis: str) -> List[str]:
        """Generate search queries from a hypothesis statement."""
        queries = [hypothesis]

        # Add "evidence for" and "evidence against" queries
        queries.append(f"evidence for: {hypothesis}")
        queries.append(f"evidence against: {hypothesis}")
        queries.append(f"analysis: {hypothesis}")

        return queries[:4]  # Cap at 4 queries
