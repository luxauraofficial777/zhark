# ZHARK — Autonomous Long-Horizon Research & Strategy Engine

## Architecture Blueprint

**ZHARK** is a domestic, autonomous long-horizon research and strategy engine — our local equivalent to Sakana Marlin. It acts as a Virtual CSO, running multi-hour investigation cycles that form hypotheses, gather web data, resolve contradictions, map causal relationships, and synthesize executive-ready strategic options.

---

## Core Design Principles

### 1. Autonomous Multi-Hour Execution
ZHARK runs an asynchronous orchestration loop capable of continuous, multi-step investigation cycles without human intervention. Each cycle:
- Forms hypotheses from the research question
- Gathers web evidence autonomously
- Analyzes and verifies findings
- Resolves contradictions
- Refines and deepens investigation
- Synthesizes strategy when convergence is reached

State is checkpointed to SQLite every cycle, enabling resume across sessions, crashes, or intentional stops.

### 2. Causal Mapping & Strategy Synthesis
Unlike summarization engines, ZHARK maps **causal relationships** — not just correlations. The causal DAG identifies:
- **Direct causes**: A → B
- **Mediated relationships**: A → M → B
- **Confounders**: C → A, C → B
- **Feedback loops**: A → B → A (detected and flagged)
- **Inhibitors**: A ⊣ B

**Leverage points** — nodes with high centrality × controllability — feed directly into strategy synthesis, identifying interventions with maximum downstream impact.

### 3. Inference-Time Compute Scaling
ZHARK implements test-time compute scaling through a **Verification Buffer** that:
- Generates multiple candidate outputs for the same query (configurable: 3-5 candidates)
- Scores each for consistency (pairwise text similarity), evidence alignment, and quality
- Tracks convergence across revisions (score improvement trend)
- Requests refinement when candidates contradict or scores are low
- Accepts output only when consensus threshold is met

This allows local models to "think longer" on hard problems, trading compute for quality.

---

## Orchestration Loop

```
┌─────────────────────────────────────────────────────────────┐
│                    ZHARK Orchestration Loop                  │
│                                                              │
│  ┌──────────┐    ┌──────────┐    ┌──────────┐    ┌────────┐ │
│  │HYPOTHESIS│───→│ GATHER   │───→│ ANALYZE  │───→│ VERIFY │ │
│  │  FORM    │    │ WEB DATA │    │ EVIDENCE │    │ BUFFER │ │
│  └──────────┘    └──────────┘    └──────────┘    └────┬───┘ │
│       ↑               │              │               │     │
│       │               │              │               ↓     │
│  ┌────┴──────┐  ┌─────┴────┐  ┌─────┴─────┐  ┌──────────┐ │
│  │  REFINE   │←─│ CONTRADICT│←─│  CAUSAL   │←─│  SCORE   │ │
│  │  SUB-HYP  │  │  DETECT   │  │  MAP UPD  │  │ CONVERGE │ │
│  └───────────┘  └──────────┘  └───────────┘  └──────────┘ │
│       │                                                      │
│       ↓                                                      │
│  ┌───────────┐                                              │
│  │SYNTHESIZE │ ← Convergence threshold met or max iterations│
│  │ STRATEGY  │                                               │
│  └───────────┘                                              │
│       │                                                      │
│       ↓                                                      │
│  ┌───────────┐                                              │
│  │  REPORT   │  → Executive-ready markdown + JSON           │
│  └───────────┘                                              │
└─────────────────────────────────────────────────────────────┘
```

### Phase Details

| Phase | Action | LLM Calls | Duration |
|-------|--------|-----------|----------|
| HYPOTHESIS | Generate 3-5 testable hypotheses from research question | 1 | ~10s |
| GATHER | Web search (DuckDuckGo) + content extraction for each hypothesis | 0 | ~30s/hyp |
| ANALYZE | LLM extracts evidence (supports/refutes, weight, finding) from each result | 5/hyp | ~60s/hyp |
| VERIFY | Generate N candidates, score consistency, check convergence | 3-5/hyp | ~90s/hyp |
| CONTRADICT | Detect conflicting hypotheses, supersede weaker ones | 0 | ~1s |
| REFINE | Spawn sub-hypotheses for inconclusive findings | 1/hyp | ~10s/hyp |
| CAUSAL | LLM extracts causal relationships from supported hypotheses | 5/cycle | ~60s/cycle |
| SYNTHESIZE | Convert findings to strategic options with risk/timeline/confidence | 1 | ~30s |

**Total per cycle:** ~5-10 minutes (3 hypotheses, Ollama 7B model)  
**Full investigation:** 50 iterations × ~8 min = ~6.5 hours autonomous

---

## State Management

### SQLite Schema (4 tables)

| Table | Purpose |
|-------|---------|
| `zhark_cycles` | Research cycle metadata (question, phase, iteration, status) |
| `zhark_verification` | Verification buffer entries (query, output, score, status) |
| `zhark_checkpoints` | Full state snapshots (hypothesis graph, causal map, strategy) |
| `zhark_telemetry` | Audit trail (all events with timestamps) |

### Checkpoint/Resume

Every cycle, ZHARK saves:
1. Hypothesis graph (JSON) → SQLite + file
2. Causal map (JSON) → SQLite + file
3. Strategy options (if synthesized) → SQLite + file
4. Cycle phase + iteration → SQLite

Resume loads the latest checkpoint and continues from the saved iteration.

---

## Hypothesis Graph

```
Root: "Market demand drives adoption of X"
├── Sub: "Enterprise budget allocation is the primary constraint" [SUPPORTED, 0.82]
│   ├── Sub: "Fortune 500 IT budgets grew 15% YoY" [SUPPORTED, 0.91]
│   └── Sub: "SMB budgets are flat" [REFUTED, -0.62]
├── Sub: "Regulatory compliance is the main driver" [INCONCLUSIVE, 0.12]
│   ├── Sub: "GDPR enforcement increased adoption" [SUPPORTED, 0.71]
│   └── Sub: "Non-EU markets show equal adoption" [REFUTED, -0.55]
└── Sub: "Technology maturity enables adoption" [SUPPORTED, 0.68]
```

- **Confidence**: Weighted sum of evidence: `(support - refute) / total`
- **Status thresholds**: SUPPORTED ≥0.7 (3+ evidence), REFUTED ≤-0.5 (3+ evidence)
- **Contradiction detection**: Siblings with opposing confidence flagged automatically
- **Branching**: Inconclusive hypotheses spawn sub-hypotheses (max depth configurable)

---

## Causal Map

```
    ┌──────────┐         ┌──────────────┐
    │ IT Budget│────0.8→ │  Adoption    │
    │ Growth   │         │  Rate        │
    └──────────┘         └──────┬───────┘
         ↑                       ↑
    0.6  │                  0.7  │
         │                       │
    ┌────┴─────┐         ┌──────┴───────┐
    │ Economic │         │  Regulatory  │
    │ Recovery │    ⊣0.5 │  Pressure    │
    └──────────┘         └──────────────┘
                              ↑
                         0.4  │
                         ┌────┴────┐
                         │ GDPR    │
                         │ Enforcement│
                         └─────────┘
```

- **Leverage score**: `centrality × controllability` — identifies highest-impact intervention points
- **Edge types**: direct, mediated, confounded, feedback, inhibitor
- **Cycle detection**: DFS-based, feedback edges flagged (not removed)

---

## Verification Buffer (Inference-Time Compute Scaling)

```
Query: "Analyze hypothesis: X causes Y"
    │
    ├── Candidate 1 (temp=0.4) → Score: 0.72
    ├── Candidate 2 (temp=0.5) → Score: 0.68
    └── Candidate 3 (temp=0.6) → Score: 0.75
    
    Consensus: 0.717 (spread: 0.07)
    Status: CONSISTENT → Accepted
    
    OR
    
    Consensus: 0.45 (spread: 0.35)
    Status: CONTRADICTORY → Refine (request revision)
```

- **Convergence tracking**: Score improvement across revisions
- **Adaptive temperature**: Each candidate uses increasing temperature for diversity
- **Acceptance criteria**: Avg score ≥ threshold AND spread < 0.2

---

## Strategy Synthesis Output

Each strategic option includes:

```json
{
  "title": "Target Enterprise IT Budget Reallocation",
  "description": "Focus on Fortune 500 companies with growing IT budgets...",
  "rationale": "Supported by 8 evidence sources (confidence: 0.82)...",
  "recommended_action": "1. Develop enterprise-tier pricing. 2. Target CIO audience...",
  "risk_level": "medium",
  "timeframe": "short_term",
  "confidence": 0.78,
  "key_assumptions": ["Budget growth continues", "No economic downturn"],
  "leading_indicators": ["Enterprise pipeline growth", "CIO engagement rate"],
  "evidence_refs": ["hyp_abc123", "hyp_def456"],
  "causal_leverage_points": ["IT Budget Growth", "Adoption Rate"]
}
```

---

## Integration with Liminal Lore

ZHARK integrates with the Liminal Lore config system:

| Component | Integration |
|-----------|-------------|
| ConfigLoader | Reads `PROJECT_ROOT`, provider settings from `.env` + `liminal_lore.yaml` |
| LLMProvider | Uses the same provider abstraction (Ollama, OpenAI-compat, OpenRouter) |
| VW Nexus | Can register as an agent, query RAG, post findings as tasks |
| Setup Wizard | ZHARK env vars included in `.env` template; `--ship` validates ZHARK |

### CLI

```powershell
# Run a research cycle
python -m zhark run "What is the optimal Go-to-Market strategy for AI dev tools in 2026?"

# Run with custom parameters
python -m zhark run "Question" --max-iterations 100 --convergence 0.85

# Check status
python -m zhark status

# Resume a previous cycle
python -m zhark resume <cycle_id>

# List all cycles
python -m zhark cycles

# View report
python -m zhark report <cycle_id>
```

### Environment Variables

| Variable | Default | Description |
|----------|---------|-------------|
| `ZHARK_MAX_ITERATIONS` | 50 | Max investigation cycles |
| `ZHARK_CONVERGENCE_THRESHOLD` | 0.75 | Avg confidence to stop |
| `ZHARK_MAX_DEPTH` | 5 | Max hypothesis tree depth |
| `ZHARK_CYCLE_DELAY` | 5 | Seconds between cycles |
| `ZHARK_VERIFY_CANDIDATES` | 3 | LLM candidates per verification |

---

## Module Structure

```
tools/zhark/
├── __init__.py                    # Package exports
├── __main__.py                    # CLI (run, status, resume, cycles, report)
├── zhark_orchestrator.py          # Main async loop controller
├── zhark_hypothesis_graph.py      # Hypothesis DAG with evidence tracking
├── zhark_causal_mapper.py         # Causal relationship extraction + DAG
├── zhark_strategy_synthesizer.py  # Executive-ready strategy generation
├── zhark_state.py                 # SQLite state + VerifyBuffer
├── zhark_web_gatherer.py          # DuckDuckGo search + content extraction
├── zhark_verify.py                # VerifyBuffer re-exports
├── data/                          # SQLite state DB (runtime)
└── output/                        # Reports + checkpoints (runtime)
```

---

## Comparison to Sakana Marlin

| Capability | Marlin | ZHARK |
|-----------|--------|-------|
| Autonomous multi-hour execution | ✓ | ✓ (checkpoint/resume) |
| Hypothesis formation | ✓ | ✓ (LLM + graph) |
| Web data gathering | ✓ | ✓ (DuckDuckGo) |
| Contradiction resolution | ✓ | ✓ (automatic supersede) |
| Causal mapping | Partial | ✓ (full causal DAG) |
| Strategy synthesis | Partial | ✓ (executive-ready) |
| Inference-time compute scaling | ✓ | ✓ (verification buffer) |
| State management | ✓ | ✓ (SQLite) |
| Local model support | Limited | ✓ (Ollama, vLLM, any OpenAI-compat) |
| Self-hosted | ✗ | ✓ (no cloud dependency) |
| Cost | API usage fees | Free (local models) |

---

## Future Extensions

1. **Multi-corpus RAG**: Query VW Nexus RAG alongside web search
2. **Committee verification**: Multiple models verify each hypothesis
3. **Active learning**: ZHARK requests specific data from user when stuck
4. **Streaming output**: WebSocket-based real-time progress to VW Deck
5. **Export formats**: PowerPoint, Notion, Confluence integration
6. **Scheduled runs**: Cron-like autonomous research cycles
